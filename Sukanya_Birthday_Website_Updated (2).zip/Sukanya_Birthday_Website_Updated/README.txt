SUKANYA 19TH BIRTHDAY LOVE WEBSITE
=================================

Included:
- index.html
- assets/p1.jpeg ... p27.jpeg
- assets/birthday-song.mp3 (your uploaded song)
- Fully animated birthday flow
- 19-year counting animation
- Animated cake cutting
- Balloon rise + fireworks
- Birthday card using P11 as the background
- Sukanya name in a romantic font
- 27-photo animated memory sequence
- Love letter with the "waiting for you" promise highlighted
- Emotional I LOVE YOU ending + whole-life waiting line
- Replay button
- Background music

HOW TO RUN:
1. Extract the ZIP.
2. Double-click index.html.
3. Click "Open Your Birthday Story ♥" — this is required by browsers so the song can start.
4. The rest of the story runs automatically.

HOW TO PUT IT ONLINE:
- GitHub Pages: create a repository, upload the extracted files, then enable Pages.
- Netlify: drag the whole extracted folder into Netlify's deploy area.
- Any normal web hosting also works.

IMPORTANT:
The browser cannot reliably autoplay audio before the visitor interacts with the page, so the first "Open Your Birthday Story" click starts the song.
The photo captions are original romantic lines. The website does NOT reproduce song lyrics. If you have the lyrics and have the rights/permission to use them, replace the `captions` array in index.html with your exact lines and adjust the 14500ms timing if needed.


UPDATED:
- Added the 14 uploaded photos as p14.jpeg through p27.jpeg.
- Gallery now contains 27 photos and keeps the same fade/zoom slideshow style.
- Photo counter and captions were updated for all 27 photos.
